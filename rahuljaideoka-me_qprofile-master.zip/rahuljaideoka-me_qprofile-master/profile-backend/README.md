# Profile BE

## Testing

```bash
npm test
```

## Local Run

```bash
npm install && npm start
```

## Deployment

After signing up on Heroku, create a new app, and proceed to download Heroku CLI

```bash
heroku login -i
heroku builds:create -a <name_of_your_app>
```